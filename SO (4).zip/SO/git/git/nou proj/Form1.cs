﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using System.Globalization;
using System.Diagnostics;
using static System.Net.Mime.MediaTypeNames;

namespace ejercicio_individual
{
    public partial class Form1 : Form
    {

        
        PictureBox dau = new PictureBox();
        Socket server;
        Thread atender;
        int codigo=0, hour, minute, miId;
        int opc;
        string username,password, mssg;
        Form2 f2 = new Form2();
       
        PictureBox pictureBox = new PictureBox();
        string inv;
        Random rnd = new Random();
        List<Point> posiciones = new List<Point>();
        List<string> conectados = new List<string>();
        List<string> invitados = new List<string>();
        Stopwatch contador = new Stopwatch();

       
        int pou_contador_J2 = 3;
        int pou_contador_J3 = 3;
        int posada_count = 3;
        int posada_count_J2 = 3;
        int posada_count_J3 = 3;
        int carcel_count = 3;
        int carcel_count_J2 = 3;
        int carcel_count_J3 = 3;

        string tiempo;
        int cont1 = 0;
        int cont2 = 66;
        int cont3 = 132;
        int turno;
        int siguiente_turno;
        int pou_contador = 3;

        public Form1()
        {
           
            InitializeComponent();
            button1.BackColor = Color.Red;
            button6.BackColor = Color.Red;
            //BackColor = Color.Red;
            label1.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            textBox1.Visible = false;
            
            textBox2.Visible = false;
            textBox3.Visible = false;
            textBox4.Visible = false;
            button2.Visible = false;
            button5.Visible = false;
            radioButton1.Visible = false;
            radioButton2.Visible = false;
            radioButton3.Visible = false;
            button4.Visible = false;
            conectadosGrid.Visible = false;
            textBox6.Visible = false;
            textBox7.Visible = false;
            textBox8.Visible = false;

            label7.Visible = false;
            label9.Visible = false;
            button8.Visible = false;
            button11.Visible = false;
            button12.Visible = false;
            
        }

        private void Clientthread()
        {
            
            Form1 form1 = new Form1();
            int num;
            string[] array;
            int i;
            while (true)
            {
                byte[] msg2 = new byte[80];
                server.Receive(msg2);

                string mssg = Encoding.ASCII.GetString(msg2).Split('\0')[0];
                array = mssg.Split('/');
               
                    

               num = Convert.ToInt32(array[0]);

                // MessageBox.Show(mssg);


                switch (num)
                {
                    case 0: //loguearse
                            //"0/1"
                        int resp = Convert.ToInt32(array[1]);
                        if (resp == 1)
                        {

                            MessageBox.Show("Usted se ha loggeado");

                            this.Invoke(new Action(() =>
                            {
                                textBox1.Text = this.username;
                                BackColor = Color.Green;
                            }));
                        }
                        else
                        {
                            MessageBox.Show("Usted no ha introducido unas credenciales correctas. Debe registrarse:");
                        }

                        break;
                    case 1:
                        //"1/1"
                        //registrarse

                        if (Convert.ToInt32(array[1]) == 1)
                        {

                            MessageBox.Show("Usted se ha registrado");

                        }
                        else
                        {
                            MessageBox.Show("Usted ha introducido algun campo incorrecto");
                        }
                        break;
                    case 2:
                        //"2/3/mariano/5victorias"/
                        //consultes
                        if (Convert.ToInt32(array[1]) == 1)
                        {
                            MessageBox.Show("El jugador con mas partidas ganadas es: " + array[2] + ",con " + array[3] + " victorias");
                        }
                        else if (Convert.ToInt32(array[1]) == 2)
                        {
                            MessageBox.Show("El jugador mas malo es: " + array[2] + ",con " + array[3] + " victorias");
                        }
                        else if (Convert.ToInt32(array[1]) == 3)
                        {
                            MessageBox.Show("El jugador mas guapo es: " + array[2] + " felicidadades");
                        }
                        break;
                    case 3:
                        //3/NUM.CONECTATS/NOMS/NOMS
                        //3/(1,2)/NUM.CONECTATS/NOMS/NOMS
                        //Veure conectats

                        /* if (Convert.ToInt32(array[1])==1)
                         {*/
                        
                        this.Invoke(new Action(() =>
                        {

                            int rows = Convert.ToInt32(array[1]);

                            conectadosGrid.ColumnCount = 1;
                            conectadosGrid.RowCount = rows;
                            conectadosGrid.Columns[0].Name = "Username";

                            conectadosGrid.Rows.Clear();


                            for (i = 2; i <= rows + 1; i++)
                            {
                                conectadosGrid.Rows.Add(array[i]);
                                conectados.Add(array[i]);


                            }

                        }));


                        break;
                    case 4:
                        //4/NOM/TEXT
                        this.Invoke(new Action(() =>
                        {
                            string user = array[1];
                            string text = array[2];
                            string chat = user + ": " + text + "\t\t\t" + DateTime.Now.ToString("HH:mm:ss tt"); ;
                            textBox4.AppendText(chat + Environment.NewLine);
                        }));

                        break;
                    case 5:
                        //5/persona que t'invita
                        this.Invoke(new Action(() =>
                        {
                            textBox6.Visible = true;
                           
                            label7.Visible = true;
                            label9.Visible = true;
                            button11.Visible = true;
                            button12.Visible = true;
                            textBox6.Text = array[1];
                        }));
                        break;
                    case 6:
                        //6/1/3/Arnau/IvanMiguel
                        //6/opc{0,1,2}/NUM_INVITATS/
                        if (Convert.ToInt32(array[1]) == 0)
                        {
                            //LA PERSONA NO HA ACCEPTAT INVITACIO
                            this.Invoke(new Action(() =>
                            {
                                
                                invitadosGridView.Rows.Clear();
                            }));

                           
                            MessageBox.Show("El usuario " + array[2] + " no ha aceptado invitación");
                        }
                        else if (Convert.ToInt32(array[1]) == 1)
                        {
                            this.Invoke(new Action(() =>
                            {
                                //La llista de invitats a partida està plena (4)
                                
                            }));
                        }
                        else if (Convert.ToInt32(array[1]) == 2)
                        {
                            this.Invoke(new Action(() =>
                            {
                                int rows = Convert.ToInt32(array[2])+1;

                                invitadosGridView.ColumnCount = 1;
                                invitadosGridView.RowCount = rows+3;
                                invitadosGridView.Columns[0].Name = "Username";

                                invitadosGridView.Rows.Clear();


                                for (i = 3; i <= rows; i++)
                                {
                                    invitadosGridView.Rows.Add(array[i]);
                                    invitados.Add(array[i]);


                                }


                                
                            }));
                        }
                        else if (Convert.ToInt32(array[1]) == 3)
                        {
                            this.Invoke(new Action(() =>
                            { 
                                this.miId = Convert.ToInt32(array[2]);
                                label6.Visible = true;
                                textBox7.Visible = true;
                                textBox7.Text = this.miId.ToString();
                            }));
                        }
                        break;
                    case 7:
                        //7/1
                        if (Convert.ToInt32(array[1]) == 1)
                        {
                            this.Invoke(new Action(() =>
                            {
                                label1.Visible = false;
                                label3.Visible = false;
                                label4.Visible = true;
                                label5.Visible = false;
                                button11.Visible = false;
                                button12.Visible = false;
                                textBox1.Visible = false;
                                textBox2.Visible = false;
                                textBox3.Visible = true;
                                textBox4.Visible = true;
                                textBox5.Visible = false;
                                button10.Visible = false;
                                button11.Visible = false;
                                button12.Visible = false;

                                button1.Visible = false;
                                button2.Visible = false;
                                button3.Visible = false;

                                button5.Visible = false;
                                button6.Visible = false;

                                button8.Visible = true;
                                button9.Visible = false;

                                radioButton1.Visible = false;
                                radioButton2.Visible = false;
                                radioButton3.Visible = false;

                                textBox8.Visible = true;
                                turno = Convert.ToInt32(array[1]);
                                contador.Start();
                                timer2.Start();
                            }));
                        }
                       
                        break;
                    case 8: //8/1/cont1
                        this.Invoke(new Action(() =>
                        {
                            int t = Convert.ToInt32(array[1]);
                            int movimiento = Convert.ToInt32(array[2]);
                            textBox9.Text = array[3];
                            siguiente_turno = Convert.ToInt32(array[3]);

                            switch (t)
                            {
                                case 1:
                                    this.cont1 = movimiento;
                                    jugador1Lbl.Location = posiciones[cont1];
                                    turno = siguiente_turno;
                                    break;
                                case 2:
                                    this.cont2 = movimiento;
                                    jugador2Lbl.Location = posiciones[cont2];
                                    turno = siguiente_turno;
                                    break;
                                case 3:
                                    this.cont3 = movimiento;
                                    jugador3Lbl.Location = posiciones[cont3];
                                    turno = siguiente_turno;
                                    break;
                                case 5:
                                    //GUANYEM
                                    cont1 = 0;
                                    cont2 = 66;
                                    cont3 = 132;
                                    timer2.Stop();
                                    MessageBox.Show("PARTIDA TERMINADA");
                                    string chat = "La partida ha durado" + this.tiempo;
                                    textBox4.AppendText(chat + Environment.NewLine);
                                    break;
                            }
                            if(cont1 == 65 || cont2 == 131 || cont3 == 197)
                            {

                                this.Close();
                            }
                         
                        }));
                        break;
                    case 9://9/username/text/1
                        this.Invoke(new Action(() =>
                        {
                            if (Convert.ToInt32(array[3]) == 1)
                            {
                                this.Close();
                            }
                            else
                            {
                                string user = array[1];
                                string text = array[2];
                                string chat = user + ": " + text;
                                textBox10.AppendText(chat + Environment.NewLine);
                            }
                            

                        }));
                        break;

                }
                
            }
                
               
                

                
        }

        
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            this.codigo = 1;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            this.codigo = 2;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            this.codigo = 3;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                this.mssg = this.codigo+"/hola";
                byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                server.Send(m);
              }
            catch (SocketException ex)
            {
                Console.WriteLine(ex);
                return;
            }
        }

       

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            if(button6.BackColor == Color.Red)
            {
                MessageBox.Show("Primero tiene que establecer conexion con el servidor...");
            }
            else
            {
                this.username = "";
                this.password = "";
                f2.ShowDialog();
                string creds = f2.getCreds();
                string[] array = creds.Split(':');
                this.username = array[0];
                this.password = array[1];
                try
                {
                    this.mssg = "6/" + this.username + "/" + this.password;
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                   
                }
                catch (SocketException ex)
                {
                    Console.WriteLine(ex);
                    return;
                }
            }
            


        }

        private void tableLayoutPanel23_Paint(object sender, PaintEventArgs e)
        {
            
        }

        
        private void Form1_Load(object sender, EventArgs e)
            {

            posiciones.Add(new Point(12, 376)); // 0 (Salida)
            posiciones.Add(new Point(56, 375)); // 1
            posiciones.Add(new Point(107, 376)); // 2
            posiciones.Add(new Point(156, 376)); // 3
            posiciones.Add(new Point(203, 376)); // 4
            posiciones.Add(new Point(253, 376)); // 5 - oca 1 rojo
            posiciones.Add(new Point(302, 376)); // 6 - puente 1 rojo
            posiciones.Add(new Point(350, 376)); // 7
            posiciones.Add(new Point(400, 376)); // 8
            posiciones.Add(new Point(449, 376)); // 9
            posiciones.Add(new Point(449, 321)); // 10
            posiciones.Add(new Point(449, 270)); // 11
            posiciones.Add(new Point(449, 213)); // 12 - puente 2 rojo
            posiciones.Add(new Point(449, 164)); // 13
            posiciones.Add(new Point(449, 112)); // 14 - oca 2 rojo
            posiciones.Add(new Point(449, 59));  // 15
            posiciones.Add(new Point(449, 9));   // 16
            posiciones.Add(new Point(401, 9));   // 17
            posiciones.Add(new Point(353, 9));   // 18
            posiciones.Add(new Point(302, 9));   // 19
            posiciones.Add(new Point(254, 9));   // 20
            posiciones.Add(new Point(205, 9));   // 21 - oca 3 rojo
            posiciones.Add(new Point(156, 9));   // 22
            posiciones.Add(new Point(106, 9));   // 23
            posiciones.Add(new Point(57, 9));   // 24
            posiciones.Add(new Point(10, 9));    // 25
            posiciones.Add(new Point(10, 59));   // 26 - dados dobles 1 rojo
            posiciones.Add(new Point(10, 110));  // 27 - oca 4 rojo
            posiciones.Add(new Point(10, 164));  // 28
            posiciones.Add(new Point(10, 214));  // 29
            posiciones.Add(new Point(10, 268));  // 30
            posiciones.Add(new Point(10, 320));  // 31 - pozo rojo
            posiciones.Add(new Point(59, 320));  // 32 - oca 5 rojo
            posiciones.Add(new Point(109, 320)); // 33
            posiciones.Add(new Point(156, 320)); // 34
            posiciones.Add(new Point(204, 320)); // 35
            posiciones.Add(new Point(254, 320)); // 36 - oca 6 rojo
            posiciones.Add(new Point(303, 320)); // 37
            posiciones.Add(new Point(352, 320)); // 38
            posiciones.Add(new Point(402, 320)); // 39
            posiciones.Add(new Point(402, 266)); // 40
            posiciones.Add(new Point(402, 212)); // 41 - oca 7 rojo
            posiciones.Add(new Point(402, 162)); // 42 - laberinto rojo
            posiciones.Add(new Point(402, 110)); // 43
            posiciones.Add(new Point(402, 59));  // 44
            posiciones.Add(new Point(352, 59));  // 45 - oca 8 rojo
            posiciones.Add(new Point(303, 59));  // 46
            posiciones.Add(new Point(254, 59));  // 47
            posiciones.Add(new Point(205, 59));  // 48
            posiciones.Add(new Point(155, 59));  // 49
            posiciones.Add(new Point(108, 59));  // 50 - oca 9 rojo
            posiciones.Add(new Point(60, 59));   // 51
            posiciones.Add(new Point(60, 110));  // 52 - carcel rojo
            posiciones.Add(new Point(60, 164));  // 53 - doble dado 2 rojo
            posiciones.Add(new Point(60, 212));  // 54 - oca 10 rojo
            posiciones.Add(new Point(60, 268));  // 55
            posiciones.Add(new Point(107, 268)); // 56
            posiciones.Add(new Point(156, 268)); // 57
            posiciones.Add(new Point(206, 268)); // 58 - muerte
            posiciones.Add(new Point(254, 268)); // 59 - oca 11 rojo (directa a la victoria)
            posiciones.Add(new Point(303, 268)); // 60
            posiciones.Add(new Point(351, 268)); // 61
            posiciones.Add(new Point(351, 214)); // 62
            posiciones.Add(new Point(351, 163)); // 63
            posiciones.Add(new Point(351, 112)); // 64
            posiciones.Add(new Point(218, 180)); // 65 - victoria rojo
                                                 //posiciones azul


            posiciones.Add(new Point(32, 377)); // 66 (salida)
            posiciones.Add(new Point(81, 377)); // 67
            posiciones.Add(new Point(133, 377)); // 68
            posiciones.Add(new Point(179, 377)); // 69
            posiciones.Add(new Point(228, 377)); // 70
            posiciones.Add(new Point(276, 377)); // 71 - oca 1 azul
            posiciones.Add(new Point(325, 377)); // 72 - puente 1 azul
            posiciones.Add(new Point(375, 377)); // 73
            posiciones.Add(new Point(424, 377)); // 74
            posiciones.Add(new Point(472, 377)); // 75
            posiciones.Add(new Point(472, 322)); // 76
            posiciones.Add(new Point(472, 271)); // 77
            posiciones.Add(new Point(472, 214)); // 78 - puente 2 azul
            posiciones.Add(new Point(472, 165)); // 79
            posiciones.Add(new Point(472, 114)); // 80 - oca 2 azul
            posiciones.Add(new Point(472, 60));  // 81
            posiciones.Add(new Point(472, 10));   // 82
            posiciones.Add(new Point(424, 10));   // 83
            posiciones.Add(new Point(376, 10));   // 84 - oca 3 azul
            posiciones.Add(new Point(325, 10));   // 85 - posada azul
            posiciones.Add(new Point(277, 10));   // 86
            posiciones.Add(new Point(229, 10));   // 87
            posiciones.Add(new Point(181, 10));   // 88 
            posiciones.Add(new Point(131, 10));   // 89 - oca 4 azul
            posiciones.Add(new Point(82, 10));    // 90
            posiciones.Add(new Point(31, 8));    // 91
            posiciones.Add(new Point(31, 60));    // 92 - dados dobles 1 azul
            posiciones.Add(new Point(31, 111));   // 93 - oca 5 azul
            posiciones.Add(new Point(31, 165));   // 94
            posiciones.Add(new Point(31, 215));   // 95
            posiciones.Add(new Point(31, 269));   // 96
            posiciones.Add(new Point(31, 320));   // 97 - pozo azul
            posiciones.Add(new Point(81, 322));  // 98- oca 6 azul
            posiciones.Add(new Point(129, 322));  // 99
            posiciones.Add(new Point(177, 322));  // 100
            posiciones.Add(new Point(227, 322));  // 101
            posiciones.Add(new Point(275, 322));  // 102 - oca 7 azul
            posiciones.Add(new Point(325, 322));  // 103
            posiciones.Add(new Point(374, 323));  // 104
            posiciones.Add(new Point(423, 320));  // 105
            posiciones.Add(new Point(423, 269));  // 106
            posiciones.Add(new Point(423, 213));  // 107- oca 8 azul
            posiciones.Add(new Point(423, 164));  // 108 - laberinto azul
            posiciones.Add(new Point(423, 110));  // 109
            posiciones.Add(new Point(423, 61));   // 110
            posiciones.Add(new Point(376, 61));   // 111 - oca 9 azul
            posiciones.Add(new Point(327, 61));   // 112
            posiciones.Add(new Point(279, 61));   // 113
            posiciones.Add(new Point(230, 61));   // 114
            posiciones.Add(new Point(181, 61));   // 115
            posiciones.Add(new Point(132, 61));   // 116 - oca 10 azul
            posiciones.Add(new Point(82, 61));    // 117
            posiciones.Add(new Point(82, 112));   // 118 - carcel azul
            posiciones.Add(new Point(82, 165));   // 119 - doble dado 2 azul
            posiciones.Add(new Point(82, 214));   // 120 - oca 10 azul
            posiciones.Add(new Point(82, 270));   // 121
            posiciones.Add(new Point(130, 270));  // 122
            posiciones.Add(new Point(180, 270));  // 123
            posiciones.Add(new Point(227, 270));  // 124 - muerte
            posiciones.Add(new Point(277, 270));  // 125 - oca 11 azul (directa a la victoria)
            posiciones.Add(new Point(325, 270));  // 126
            posiciones.Add(new Point(373, 270));  // 127
            posiciones.Add(new Point(373, 216));  // 128
            posiciones.Add(new Point(373, 164));  // 129
            posiciones.Add(new Point(373, 114));  // 130
            posiciones.Add(new Point(223, 182));  // 131 - victoria azul



            //posiciones verde

            posiciones.Add(new Point(22, 396)); // 132 (salida)
            posiciones.Add(new Point(70, 397)); // 133
            posiciones.Add(new Point(118, 400)); // 134
            posiciones.Add(new Point(164, 400)); // 135
            posiciones.Add(new Point(213, 400)); // 136
            posiciones.Add(new Point(264, 400)); // 137 - oca 1 verde
            posiciones.Add(new Point(313, 400)); // 138 - puente 1 verde
            posiciones.Add(new Point(361, 400)); // 139
            posiciones.Add(new Point(411, 400)); // 140
            posiciones.Add(new Point(460, 400)); // 141
            posiciones.Add(new Point(460, 345)); // 142
            posiciones.Add(new Point(460, 294)); // 143
            posiciones.Add(new Point(460, 241)); // 144 - puente 2 verde
            posiciones.Add(new Point(460, 188)); // 145
            posiciones.Add(new Point(460, 137)); // 146 - oca 2 verde
            posiciones.Add(new Point(460, 83));  // 147
            posiciones.Add(new Point(460, 33));  // 148
            posiciones.Add(new Point(412, 33));  // 149
            posiciones.Add(new Point(363, 33));  // 150 - oca 3 verde
            posiciones.Add(new Point(312, 33));  // 151 - posada verde
            posiciones.Add(new Point(265, 33));  // 152
            posiciones.Add(new Point(214, 33));  // 153
            posiciones.Add(new Point(167, 33));  // 154
            posiciones.Add(new Point(118, 33));  // 155 - oca 4 verde
            posiciones.Add(new Point(70, 33));   // 156
            posiciones.Add(new Point(21, 33));   // 157
            posiciones.Add(new Point(21, 83));   // 158 - dados dobles 1 verde
            posiciones.Add(new Point(21, 137));  // 159 - oca 5 verde
            posiciones.Add(new Point(21, 188));  // 160
            posiciones.Add(new Point(21, 241));  // 161
            posiciones.Add(new Point(21, 294));  // 162
            posiciones.Add(new Point(21, 344));  // 163 - pozo verde
            posiciones.Add(new Point(70, 344));  // 164 - oca 6 verde
            posiciones.Add(new Point(120, 344)); // 165
            posiciones.Add(new Point(166, 344)); // 166
            posiciones.Add(new Point(214, 344)); // 167
            posiciones.Add(new Point(263, 344)); // 168 - oca 7 verde
            posiciones.Add(new Point(312, 344)); // 169
            posiciones.Add(new Point(363, 344)); // 170
            posiciones.Add(new Point(411, 290)); // 171
            posiciones.Add(new Point(411, 293)); // 172
            posiciones.Add(new Point(411, 242)); // 173 - oca 8 verde
            posiciones.Add(new Point(411, 187)); // 174 - laberinto verde
            posiciones.Add(new Point(411, 139)); // 175
            posiciones.Add(new Point(411, 85));  // 176
            posiciones.Add(new Point(363, 85));  // 177 - oca 9 verde
            posiciones.Add(new Point(312, 85));  // 178
            posiciones.Add(new Point(263, 85));  // 179
            posiciones.Add(new Point(214, 85));  // 180
            posiciones.Add(new Point(165, 85));  // 181
            posiciones.Add(new Point(119, 85));  // 182 - oca 10 verde
            posiciones.Add(new Point(70, 85));   // 183
            posiciones.Add(new Point(70, 137));  // 184 - carcel verde
            posiciones.Add(new Point(70, 186));  // 185 - doble dado 2 verde
            posiciones.Add(new Point(70, 242));  // 186 - oca 10 verde
            posiciones.Add(new Point(70, 293));  // 187
            posiciones.Add(new Point(118, 293)); // 188
            posiciones.Add(new Point(166, 293)); // 189
            posiciones.Add(new Point(217, 293)); // 190 - muerte
            posiciones.Add(new Point(266, 293)); // 191 - oca 11 verde (directa a la victoria)
            posiciones.Add(new Point(315, 293)); // 192
            posiciones.Add(new Point(362, 293)); // 193
            posiciones.Add(new Point(362, 242)); // 194
            posiciones.Add(new Point(362, 187)); // 195
            posiciones.Add(new Point(362, 138)); // 196
            posiciones.Add(new Point(216, 180)); // 197 - victoria verde




        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            try
            {
                this.codigo = 4;
                this.mssg = this.codigo+"/";
                byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                server.Send(m);
            }
            catch (SocketException ex)
            {
                Console.WriteLine(ex);
                return;
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            
        }

        private void button7_Click(object sender, EventArgs e)
        {

            /*if (turno == miId && pou_contador == 3)
            {
                timer1.Interval = 1000;
                timer1.Start();
            }
            else if(turno != miId && pou_contador == 3)
            {
                
                MessageBox.Show("No es tu turno");
            }
            else
            {
                pou_contador++;
                turno++;
            }*/

            /* try
             {
                 this.mssg = "12/"+turno;
                 byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                 server.Send(m);
             }
             catch (SocketException ex)
             {
                 Console.WriteLine(ex);
                 return;
             }*/
           
           /* if (turno == miId && pou_contador == 3 && posada_contador == 3 && preso_contador == 3)
            {
                timer1.Interval = 1000;
                timer1.Start();
            }else if(turno == miId && pou_contador != 3)
            {
                turno++;
                pou_contador++;
                MessageBox.Show("No es tu turno");
            }else if(turno == miId && posada_contador != 3)
            {
                turno++;
                posada_contador++;
                MessageBox.Show("No es tu turno");
            }
            else if(turno == miId && preso_contador != 3)
            {
                turno++;
                preso_contador++;
                MessageBox.Show("No es tu turno");
            }

            else
            {
                MessageBox.Show("No es tu turno");
            }*/

            if (turno == miId && (pou_contador != 3 || posada_count != 3 || carcel_count != 3))
            {

                if (pou_contador != 3)
                {
                    if(cont1==31 && cont2 == 97 || cont1 == 31 && cont3==163 || cont2 == 97 && cont3 == 163)
                    {
                        pou_contador = 3;
                        string missg = "13/" + username + "/Sales del pozo/0";
                        byte[] ma = System.Text.Encoding.ASCII.GetBytes(missg);
                        server.Send(ma);
                    }
                    else
                    {
                        pou_contador++;
                        string missg = "13/" + username + "/POZO,Se te salta el turno/0";
                        byte[] ma = System.Text.Encoding.ASCII.GetBytes(missg);
                        server.Send(ma);
                    }
                    
                    
                }
                if (posada_count != 3)
                {
                    posada_count++;
                    string missg = "13/" + username + "/POSADA,Se te salta el turno/0";
                    byte[] ma = System.Text.Encoding.ASCII.GetBytes(missg);
                    server.Send(ma);
                }
                if (carcel_count != 3)
                {
                    carcel_count++;
                    string missg = "13/" + username + "/CARCEL,Se te salta el turno/0";
                    byte[] ma = System.Text.Encoding.ASCII.GetBytes(missg);
                    server.Send(ma);
                }
                siguiente_turno = turno;
                if (turno == 3)
                {
                    siguiente_turno = 1;
                }
                else siguiente_turno++;
                
                if(miId == 1)
                {
                    string mssg = "11/" + miId + "/"+cont1+"/" + siguiente_turno;
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }else if(miId == 2)
                {
                    string mssg = "11/" + miId + "/"+cont2+"/" + siguiente_turno;
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                else
                {
                    string mssg = "11/" + miId + "/"+cont3+"/" + siguiente_turno;
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }

                
                
            }
            else if(turno != miId)
            {
                MessageBox.Show("NO es tu turno");
            }
            else
            {
                timer1.Interval = 1000;
                timer1.Start();
            }




        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            int puente1_count = 0;
            
            int Repetir_Tirada = 0;
            int Oca1_Count = 0;
            int Oca2_Count = 0;
            int Oca3_Count = 0;
            int Oca4_Count = 0;
            int Oca5_Count = 0;
            int Oca6_Count = 0;
            int Oca7_Count = 0;
            int Oca8_Count = 0;
            int Oca9_Count = 0;
            int Oca10_Count = 0;
            int Oca11_Count = 0;

            Random rnd = new Random();
            int cara = rnd.Next(1, 7);

            System.Drawing.Image dau = System.Drawing.Image.FromFile(@"C:\Arnau\Uni\SO\git\cara_" + cara + ".png");
            pictureBox1.Image = dau;

            this.mssg = "13/"+username + "/ha sacado un " + cara+"/0";
            byte[] ma = System.Text.Encoding.ASCII.GetBytes(mssg);
            server.Send(ma);

           
           
           
           

            if (turno == 1)
            {
                cont1 = cont1 + cara;
                //Miramos los movimientos cuando caiga a una Oca
                if (cont1 > 65)
                {
                    int resta = cont1 - 65;
                    cont1 = 65 - resta;
                }
                
                    if (cont1 == 5)//oca 1 a oca 2
                    {
                        cont1 = 14; // Incremento en 1
                        Repetir_Tirada = 1;
                        Oca1_Count = 1;
                        this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                    if (cont1 == 14 && Oca1_Count == 0) //Oca 2 a Oca 3 si no viene de oca 1 a oca 2
                    {
                        cont1 = 18; // Incremento en 1
                        Repetir_Tirada = 1;
                        Oca2_Count = 1;
                        this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                    if (cont1 == 18 && Oca2_Count == 0) //Oca 3 a Oca 4 si no viene de oca 2 a oca 3
                    {
                        cont1 = 23; // Incremento en 1
                        Repetir_Tirada = 1;
                        Oca3_Count = 1;
                        this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                    if (cont1 == 19) //POSADA
                    {
                        posada_count = 1;
                        this.mssg = "13/" + username + "/" + "Has caido a la posada, un turno sin tirar/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                    if (cont1 == 23 && Oca3_Count == 0) //Oca 4 a Oca 5 si no viene de oca 3 a oca 4
                    {
                        cont1 = 27; // Incremento en 1
                        Repetir_Tirada = 1;
                        Oca4_Count = 1;
                        this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                    if (cont1 == 27 && Oca4_Count == 0) //Oca 5 a Oca 6 si no viene de oca 4 a oca 5
                    {
                        cont1 = 32; // Incremento en 1
                        Repetir_Tirada = 1;
                        Oca5_Count = 1;
                        this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                    if (cont1 == 31)
                    {
                        //POU
                        pou_contador = 0;
                        this.mssg = "13/" + username + "/" + "Has caido al pozo, tres turnos sin tirar/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                    if (cont1 == 32 && Oca5_Count == 0) //Oca 6 a Oca 7 si no viene de oca 5 a oca 6
                    {
                        cont1 = 36; // Incremento en 1
                        Repetir_Tirada = 1;
                        Oca6_Count = 1;
                        this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                    if (cont1 == 36 && Oca6_Count == 0) //Oca 7 a Oca 8 si no viene de oca 6 a oca 7
                    {
                        cont1 = 41; // Incremento en 1
                        Repetir_Tirada = 1;
                        Oca7_Count = 1;
                        this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                    if (cont1 == 41 && Oca7_Count == 0) //Oca 8 a Oca 9 si no viene de oca 7 a oca 8
                    {
                        cont1 = 45; // Incremento en 1
                        Repetir_Tirada = 1;
                        Oca8_Count = 1;
                        this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                    if (cont1 == 42) //LABERINT
                    {
                    Repetir_Tirada = 0;
                        cont1 = 30;
                        this.mssg = "13/" + username + "/" + "Has caido en el laberinto, vas a casilla 30/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                    if (cont1 == 45 && Oca8_Count == 0) //Oca 9 a Oca 10 si no viene de oca 7 a oca 8
                    {
                        cont1 = 50; // Incremento en 1
                        Repetir_Tirada = 1;
                        Oca9_Count = 1;
                        this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);

                    }
                    if (cont1 == 50 && Oca9_Count == 0) //Oca 10 a Oca 11 si no viene de oca 7 a oca 8
                    {
                        cont1 = 54; // Incremento en 1
                        Repetir_Tirada = 1;
                        Oca10_Count = 1;
                        this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                if (cont1 == 52) //PRESO
                {
                    carcel_count = 1;
                    this.mssg = "13/" + username + "/" + "Has caido a prision, tres turnos sin tirar/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                if (cont1 == 54 && Oca10_Count == 0) //Oca 10 a Oca 11 si no viene de oca 7 a oca 8
                    {
                        cont1 = 59; // Incremento en 1
                        Repetir_Tirada = 1;
                        Oca11_Count = 1;
                        this.mssg = "13/" + username + "/" +"De oca a oca y tiro porque me toca/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                    if (cont1 == 58)
                    {
                        this.mssg = "13/" + username + "/" + "Has muerto, vuelve a empezar/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                        cont1 = 0;
                    }
                    if (cont1 == 59 && Oca11_Count == 0) //Oca 10 a Oca 11 si no viene de oca 7 a oca 8
                    {
                        cont1 = 65; // Incremento en 1
                        Repetir_Tirada = 1;
                        this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                    if (cont1 == 65 && Oca11_Count == 0) //Oca 10 a Oca 11 si no viene de oca 7 a oca 8
                    {

                        this.mssg = "13/" + username + "/" + ": HAS GANADO/1";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    MessageBox.Show("HAS GANADO LA PARTIDA, FELICIDADES");
                   
                    }
                    //puente
                    if (cont1 == 6)
                    {
                        cont1 = 12;
                        this.mssg = "13/" + username + "/" + "De puente en puente y tiro porque me lleva la corriente/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                        puente1_count = 1;
                        Repetir_Tirada = 1;
                    }

                    //puente
                    if (cont1 == 12 && puente1_count == 0)
                    {
                        cont1 = 6;
                        this.mssg = "13/" + username + "/" + "De puente en puente y tiro porque me lleva la corriente/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                        Repetir_Tirada = 1;
                    }
                    if (cont1 == 26) //DAUS DOBLES
                    {
                        Repetir_Tirada = 1;
                        this.mssg = "13/" + username + "/" + "Dados dobles, vuelve a tirar/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                    if (cont1 == 53) //DAUS DOBLES
                    {
                        Repetir_Tirada = 1;
                        this.mssg = "13/" + username + "/" + "Dados dobles, vuelve a tirar/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                    if (Repetir_Tirada == 1)
                    {
                        string mens = "11/1/" + cont1 + "/1";
                        byte[] me = System.Text.Encoding.ASCII.GetBytes(mens);
                        server.Send(me);
                    }
                    else
                    {
                        string mens = "11/1/" + cont1 + "/2";
                        byte[] me = System.Text.Encoding.ASCII.GetBytes(mens);
                        server.Send(me);
                    }
                

               
                
                
            }
            else if (turno == 2)
            {
                    cont2 = cont2 + cara;

                if (cont2 > 131)
                {
                    int resta = cont2 - 131;
                    cont2 = 131 - resta;
                }


                //Miramos los movimientos cuando caiga a una Oca
                if (cont2 == 71)//oca 1 a oca 2
                {
                    cont2 = 80;
                    Repetir_Tirada = 1;
                        Oca1_Count = 1;
                    this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }

                if (cont2 == 72) //PONT
                {
                    cont2 = 78;
                    Repetir_Tirada = 1;
                    this.mssg = "13/" + username + "/" + "De puente en puente y tiro porque me lleva la corriente/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                    puente1_count = 1;
                    }
                if (cont2 == 78 && puente1_count == 0) //PUENTE
                {
                    cont2 = 72;
                    Repetir_Tirada = 1;
                    this.mssg = "13/" + username + "/" + "De puente en puente y tiro porque me lleva la corriente/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                if (cont2 == 80 && Oca1_Count == 0) //Oca 4 a Oca 5 si no viene de oca 3 a oca 4
                {
                    cont2 = 84;  // Incrementado en 1
                    Repetir_Tirada = 1;
                        Oca2_Count = 1;
                        this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                     }
                if (cont2 == 84 && Oca2_Count == 0) //Oca 5 a Oca 6 si no viene de oca 4 a oca 5
                {
                    cont2 = 89;  // Incrementado en 1
                    Repetir_Tirada = 1;
                        Oca3_Count = 1;
                        this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                if (cont2 == 89 && Oca3_Count == 0) //Oca 5 a Oca 6 si no viene de oca 4 a oca 5
                {
                    cont2 = 93;  // Incrementado en 1
                    Repetir_Tirada = 1;
                        Oca4_Count = 1;
                    this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                    }
                    if (cont2 == 85) //POSADA
                    {
                        posada_count = 1;
                        this.mssg = "13/" + username + "/" + "Has caido a la posada, un turno sin tirar/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                    if (cont2 == 93 && Oca4_Count == 0) //Oca 7 a Oca 8 si no viene de oca 6 a oca 7
                    {
                        cont2 = 98;  
                        Repetir_Tirada = 1;
                        Oca5_Count = 1;
                        this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                    if (cont2 == 92) //DAUS DOBLES
                    {
                    Repetir_Tirada = 1;
                    this.mssg = "13/" + username + "/" + "Dados dobles, vuelve a tirar/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                
                if (cont2 == 97) //POU
                    {
                        pou_contador = 0;
                        this.mssg = "13/" + username + "/" + "Has caido en el pozo, tres turnos sin tirar/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                }
                if (cont2 == 98 && Oca5_Count == 0) //Oca 10 a Oca 11 si no viene de oca 7 a oca 8
                {
                    cont2 = 102;
                    Repetir_Tirada = 1;
                        Oca6_Count = 1;
                        this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                }
                if (cont2 == 102 && Oca6_Count == 0) //Oca 10 a Oca 11 si no viene de oca 7 a oca 8
                {
                    cont2 = 107;
                    Repetir_Tirada = 1;
                        Oca7_Count = 1;
                    this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                if (cont2 == 107 && Oca7_Count == 0) //Oca 10 a Oca 11 si no viene de oca 7 a oca 8
                {
                    cont2 = 111;
                    Repetir_Tirada = 1;
                        Oca8_Count = 1;
                    this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                    if (cont2 == 108) //LABERINT
                    {
                    Repetir_Tirada = 0;
                        cont2 = 96;
                        this.mssg = "13/" + username + "/" + "Has caido en el laberinto, vas a casilla 30/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                    if (cont2 == 111 && Oca8_Count == 0) //Oca 10 a Oca 11 si no viene de oca 7 a oca 8
                    {
                        cont2 = 11;
                        Repetir_Tirada = 1;
                            Oca9_Count = 1;
                        this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                    if (cont2 == 116 && Oca9_Count == 0) //Oca 10 a Oca 11 si no viene de oca 7 a oca 8
                    {
                        cont2 = 120;
                        Repetir_Tirada = 1;
                            Oca10_Count = 1;
                        this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                    if (cont2 == 118) //PRESO
                    {
                        carcel_count = 1;
                        this.mssg = "13/" + username + "/" + "Has caido a prision, tres turnos sin tirar/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                    if (cont2 == 119) //DAUS DOBLES
                    {
                        Repetir_Tirada = 1;
                        this.mssg = "13/" + username + "/" + "Dados dobles, vuelve a tirar/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                if (cont2 == 120 && Oca10_Count == 0) //Oca 10 a Oca 11 si no viene de oca 7 a oca 8
                {
                    cont2 = 125;
                    Repetir_Tirada = 1;
                        Oca11_Count = 1;
                    this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                    if (cont2 == 124) //MORT
                    {
                        cont2 = 66;
                        this.mssg = "13/" + username + "/" + "Has muerto, vuelve a empezar/0";
                        byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                        server.Send(m);
                    }
                if (cont2 == 125 && Oca11_Count == 0) //Oca 10 a Oca 11 si no viene de oca 7 a oca 8
                {
                    cont2 = 131;
                    Repetir_Tirada = 1;
                    this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                    if (cont2 == 131) //Oca 10 a Oca 11 si no viene de oca 7 a oca 8
                    {
                    this.mssg = "13/" + username + "/" + ": HAS GANADO/1";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                    MessageBox.Show("HAS GANADO LA PARTIDA, FELICIDADES");
                    

                }

                if (Repetir_Tirada == 1)
                {
                    string mens = "11/2/" + cont2+"/2";
                    byte[] me = System.Text.Encoding.ASCII.GetBytes(mens);
                    server.Send(me);
                }
                else
                {
                    string mssg = "11/2/" + cont2 + "/3";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                
               


            }
            else if (turno == 3)
            {
                cont3 = cont3 + cara;

                if (cont3 > 197)
                {
                    int resta = cont3 - 197;
                    cont3 = 197-resta;
                }


                //Miramos los movimientos cuando caiga a una Oca
                if (cont3 == 137)//oca 1 a oca 2
                {
                    cont3 = 146;
                    Repetir_Tirada = 1;
                    Oca1_Count = 1;
                    this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                if (cont3 == 146 && Oca1_Count == 0) //Oca 2 a Oca 3 si no viene de oca 1 a oca 2
                {
                    cont3 = 150;
                    Repetir_Tirada = 1;
                    Oca2_Count = 1;
                    this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                if (cont3 == 150 && Oca2_Count == 0) //Oca 3 a Oca 4 si no viene de oca 2 a oca 3
                {
                    cont3 = 155;
                    Repetir_Tirada = 1;
                    Oca3_Count = 1;
                    this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                if (cont3 == 151) //POSADA
                {
                    posada_count = 1;
                    this.mssg = "13/" + username + "/" + "Has caido a la posada, un turno sin tirar/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                if (cont3 == 155 && Oca3_Count == 0) //Oca 4 a Oca 5 si no viene de oca 3 a oca 4
                {
                    cont3 = 159;
                    Repetir_Tirada = 1;
                    Oca4_Count = 1;
                    this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                if (cont3 == 158) //DAUS DOBLES
                {
                    Repetir_Tirada = 1;
                    this.mssg = "13/" + username + "/" + "Dados dobles, vuelve a tirar/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                if (cont3 == 159 && Oca4_Count == 0) //Oca 5 a Oca 6 si no viene de oca 4 a oca 5
                {
                    cont3 = 164;
                    Repetir_Tirada = 1;
                    Oca5_Count = 1;
                    this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                if (cont3 == 163) //POU
                {
                    pou_contador = 0;
                    this.mssg = "13/" + username + "/" + "Has caido en el pozo, tres turnos sin tirar/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                if (cont3 == 164 && Oca5_Count == 0) //Oca 6 a Oca 7 si no viene de oca 5 a oca 6
                {
                    cont3 = 168;
                    Repetir_Tirada = 1;
                    Oca6_Count = 1;
                    this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                if (cont3 == 168 && Oca6_Count == 0) //Oca 7 a Oca 8 si no viene de oca 6 a oca 7
                {
                    cont3 = 173;
                    Repetir_Tirada = 1;
                    Oca7_Count = 1;
                    this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                if (cont3 == 173 && Oca7_Count == 0) //Oca 8 a Oca 9 si no viene de oca 7 a oca 8
                {
                    cont3 = 177;
                    Repetir_Tirada = 1;
                    Oca8_Count = 1;
                    this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                if (cont3 == 174) //LABERINT
                {
                    Repetir_Tirada = 0;
                    cont3 = 162;
                    this.mssg = "13/" + username + "/" + "Has caido en el laberinto, vas a casilla 30/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                if (cont3 == 177 && Oca8_Count == 0) //Oca 9 a Oca 10 si no viene de oca 7 a oca 8
                {
                    cont3 = 182;
                    Repetir_Tirada = 1;
                    Oca9_Count = 1;
                    this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                if (cont3 == 182 && Oca9_Count == 0) //Oca 10 a Oca 11 si no viene de oca 7 a oca 8
                {
                    cont3 = 186;
                    Repetir_Tirada = 1;
                    Oca10_Count = 1;
                    this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                if (cont3 == 184) //PRESO
                {
                    carcel_count = 1;
                    this.mssg = "13/" + username + "/" + "Has caido a prision, tres turnos sin tirar/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                if (cont3 == 185) //DAUS DOBLES
                {
                    Repetir_Tirada = 1;
                    this.mssg = "13/" + username + "/" + "Dados dobles, vuelve a tirar/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                if (cont3 == 186 && Oca10_Count == 0) //Oca 11 a Oca 12 si no viene de oca 7 a oca 8
                {
                    cont3 = 191;
                    Repetir_Tirada = 1;
                    Oca11_Count = 1;
                    this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                if (cont3 == 190) //MORT
                {
                    cont2 = 132;
                    this.mssg = "13/" + username + "/" + "Has muerto, vuelve a empezar/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                if (cont3 == 191 && Oca11_Count == 0) //Oca 10 a Oca 11 si no viene de oca 7 a oca 8
                {
                    cont3 = 197;
                    Repetir_Tirada = 1;
                    this.mssg = "13/" + username + "/" + "De oca a oca y tiro porque me toca/0 ";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                if (cont3 == 197) //Oca 10 a Oca 11 si no viene de oca 7 a oca 8
                {
                    this.mssg = "13/" + username + "/" + ": HAS GANADO/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                    MessageBox.Show("HAS GANADO LA PARTIDA, FELICIDADES");
                    
                }

                //puente
                if (cont3 == 138)
                {
                    cont3 = 145;
                    this.mssg = "13/" + username + "/" + "De puente en puente y tiro porque me lleva la corriente/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                    puente1_count = 1;
                    Repetir_Tirada = 1;
                }

                //puente
                if (cont3 == 145 && puente1_count == 0)
                {
                    cont3 = 138;
                    this.mssg = "13/" + username + "/" + "De puente en puente y tiro porque me lleva la corriente/0";
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                    Repetir_Tirada = 1;
                }
                
                if (Repetir_Tirada == 1)
                {
                    string mens = "11/3/" + cont3+"/3";
                    byte[] me = System.Text.Encoding.ASCII.GetBytes(mens);
                    server.Send(me);
                }
                else
                {
                    string mens = "11/3/" + cont3+"/1";
                    byte[] me = System.Text.Encoding.ASCII.GetBytes(mens);
                    server.Send(me);
                }
               

            }
            timer1.Stop();
        }


        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
     {

     }

        private void button3_Click_1(object sender, EventArgs e)
        {
            this.codigo = 10;
            try
            {
                button1.BackColor = Color.Red;
                BackColor = Color.Red;
                this.mssg = this.codigo + "/";

                byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                server.Send(m);

                
                server.Shutdown(SocketShutdown.Both);
                server.Close();
                atender.Abort();
                conectadosGrid.Hide();
            }
            catch (SocketException ex)
            {
                Console.WriteLine("No se ha podido desconectar del servidor");
                Console.WriteLine(ex);
                return;
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.inv = textBox5.Text;
            invitadosGridView.ColumnCount = 1;
            invitados.Add(this.username);
            invitadosGridView.Rows.Add(this.username);
            string[] nombres = this.inv.Split('/');
            string mssg = "7/" + nombres.Length + "/" + this.username + "/" + this.inv;

            byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
            server.Send(m);
            textBox5.Text = "";
        }

      

        private void button8_Click(object sender, EventArgs e)
        {
            //ENVIAR CHAT
            string mssg = "5/"+this.username+"/"+textBox3.Text;
           
            byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
            server.Send(m);
            textBox3.Text = "";
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.opc = 1;
            try
            {
                this.mssg = "8/1/"+this.username;
                byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                server.Send(m);
                textBox6.Visible = false;
                
                label7.Visible = false;
                label9.Visible = false;
                button11.Visible = false;
                button12.Visible = false;
                
            }
            catch (SocketException ex)
            {
                Console.WriteLine(ex);
                return;
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.opc = 0;
            try
            {
                this.mssg = "8/0/"+this.username;
                byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                server.Send(m);
                textBox6.Visible = false;
                
                label7.Visible = false;
                label9.Visible = false;
                button11.Visible = false;
                button12.Visible = false;
            }
            catch (SocketException ex)
            {
                Console.WriteLine(ex);
                return;
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            turno = 1;

            
            try
            {
                this.mssg = "9/1";
                byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                server.Send(m);
                textBox6.Visible = false;
            }
            catch (SocketException ex)
            {
                Console.WriteLine(ex);
                return;
            }

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            TimeSpan ts = contador.Elapsed;
            textBox8.Text = "Tiempo de partida: " + ts.ToString("mm\\:ss");
            tiempo = ts.ToString("mm\\:ss");
            //textBox8.Text = "Tiempo de partida: " + ts.Minutes + "min " ": "+ts.Seconds+"seg";
        }

        private void conectadosGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int fila = e.RowIndex;
            textBox5.AppendText(conectados[fila] + Environment.NewLine);
           // invitados.Add(conectados[fila]);
        }
        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.username = textBox1.Text;
            this.password = textBox2.Text;
            if (this.username == "" || this.password == "")
            {
                MessageBox.Show("[!]FALTA INTRODUCIR CREDENCIALES");
            }
            else
            {
                try
                {
                    this.mssg = "0/" + this.username + "/" + this.password;
                    byte[] m = System.Text.Encoding.ASCII.GetBytes(mssg);
                    server.Send(m);
                }
                catch (SocketException ex)
                {
                    Console.WriteLine(ex);
                    return;
                }

            }
            textBox1.Text = "";
            textBox2.Text = "";
           
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            IPAddress newaddress = IPAddress.Parse("192.168.56.102");
            
            IPEndPoint remoteEP = new IPEndPoint(newaddress, 9051);

            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(remoteEP);
                MessageBox.Show("Conectado");
                ThreadStart ts = delegate { Clientthread(); };
                atender = new Thread(ts);
                atender.Start();
            }
            catch (SocketException ex)
            {
                Console.WriteLine("No se ha podido conectar al servidor");
                Console.WriteLine(ex);
                return;
            }





            button1.BackColor = Color.Green;
            button6.BackColor = Color.Green;
            label1.Visible = true;
            label3.Visible = true;
            textBox1.Visible = true;
            textBox2.Visible = true;
            button2.Visible = true;
            button5.Visible = true;
            radioButton1.Visible = true;
            radioButton2.Visible = true;
            radioButton3.Visible = true;
            button4.Visible = true;
            conectadosGrid.Visible = true;
        }
     public string getUsername()
        {
            return username;
        }  
            
    }
    
}
