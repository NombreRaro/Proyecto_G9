﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;

namespace Cliente
{
    public partial class Form1 : Form
    {
        Socket server;
        Thread atender;
        string username, password;
    
        public Form1()
        {
            InitializeComponent();
            button2.BackColor = Color.Red;
            button4.BackColor = Color.Red;
            button5.BackColor = Color.Red;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            IPAddress newaddress = IPAddress.Parse("192.168.145.138");
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IPEndPoint remoteEP = new IPEndPoint( newaddress , 9050);
            try            {
                server.Connect(remoteEP);
                MessageBox.Show("Conectado");
            }
            catch (SocketException ex)
            {
                MessageBox.Show("Conectado");
                Console.WriteLine("No se ha podido conectar al servidor");
                Console.WriteLine(ex);
                return;
            }
            button2.BackColor = Color.Green;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            string mensaje = "0/";

            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
          

            
            atender.Abort();
            button2.BackColor = Color.Red;
            server.Shutdown(SocketShutdown.Both);
            server.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.username = textBox1.Text;
            this.password = textBox2.Text;
            string mssg = this.username+"/"+this.password;
            byte[] credentials = System.Text.Encoding.ASCII.GetBytes(mssg);
            server.Send(credentials);
            /*byte[] msg2 = new byte[80];
            server.Receive(msg2);
            message = Encoding.ASCII.GetString(msg2).Split('\0')[0];
            MessageBox.Show(message);*/
        }
    }
}
